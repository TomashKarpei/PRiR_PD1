package symulator;

import java.util.concurrent.ThreadLocalRandom;

public class Glowna {

	public static void main(String[] args) {
		int rokStd = 2019;
		while (rokStd != 2100) {
			try {
				Thread.sleep(500);
				new Studenci(rokStd, ThreadLocalRandom.current().nextInt(80, 90 + 1)).start();
				rokStd++;
			}
			catch (InterruptedException e){
				System.out.println("Thread interrupted.");
			}
		}
	}
}
