package symulator;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class Studenci extends Thread {
    private volatile boolean exit;
    private int rokStd;
    private int ilStud;
    private int stopien = 1;
    private int sem = 1;
    private int rok = 0;
    private int x = ThreadLocalRandom.current().nextInt(40, 50 + 1);
    
    
    private Random random;

    public Studenci(int rokStd, int ilStud) {
        this.rokStd = rokStd;
        this.ilStud = ilStud;
        random = new Random();
    }

    private void wylIlStud(int StudUch) {
        System.out.println("Po " + sem + " semestrze na studjach pozosta�o " + ilStud + " student�w z " + stopien + "go stopnia z " + rokStd + " roku");
        this.ilStud = ilStud - StudUch;
    }

    private void startStud() {
        exit = false;
    }

    private void stopStud() {
        exit = true;
    }

    @Override
    public void run() {
    	startStud();
    	for (sem = 1; sem <= 10; sem++) {
    		if (rok%2 == 1)	{
    			rok++;
    		}
    		if (sem%6 == 0) {
    			stopien++;
    			if (ilStud > 0 && stopien == 2) {
    				System.out.println(ilStud + " student�w z " + rokStd + " roku, prze�yli pierwszy stopien." );
    			}
    		}
    		if (rok != 0){
    			wylIlStud(x/(sem));
    			x /= 2;
    		}
    		else {
    			wylIlStud(x/(sem));
    			x /= 2;
    		}
    		
    	}
    	

        while(!exit) {
            try {
                sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if(ilStud > 0 && stopien == 2 && sem == 10) {
            	System.out.println(ilStud + " z " + rokStd + "prze�yli studje." );
                stopStud();
                break;
            }
            else if (ilStud <= 0) {
            	System.out.println("Nikt nie prze�yl studje z " + rokStd + " roku.");
                stopStud();
                break;
            }
            
        }
        
    }
}