package calki;

class M_prostokatow extends Thread{
	double ai, bi, n, wynik_p;
	public M_prostokatow (double a, double b, double n) {
		this.ai = a;
		this.bi = b;
		this.n = n;
		
	}
	
	public void run() {
		Glowna f = new Glowna();
		double delta, suma = 0;
		delta = (bi - ai) / n;
		for (int i = 0; i < n; i++)	{
			suma += delta * f.Func(ai + delta*(i + 0.5));
		}
		wynik_p = suma;
	}

}
