package calki;

class M_Simpsona extends Thread{
	
	public double ai, bi, n, wynik_S;
	
	public M_Simpsona (double a, double b, double n) {
		this.ai = a;
		this.bi = b;
		this.n = n;
		
	}
	public void run() {
		Glowna f = new Glowna();
		double dx, calka, s, x;
		dx = (bi - ai) / (double)n;
		 
		calka = 0;
		s = 0;
		for (int i=1; i < n; i++) {
			x = ai + i*dx;
			s += f.Func(x - dx / 2);
			calka += f.Func(x);
		}
		s += f.Func(bi - dx / 2);
		calka = (dx/6) * (f.Func(ai) + f.Func(bi) + 2*calka + 4*s);
		wynik_S = calka;
	}
}
