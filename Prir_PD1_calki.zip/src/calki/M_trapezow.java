package calki;

class M_trapezow extends Thread{
	public double ai, bi, n, wynik_t;

	
	public M_trapezow (double a, double b, double n) {
		this.ai = a;
		this.bi = b;
		this.n = n;
		
	}
	
	public void run() {
		Glowna f = new Glowna();
		double dx, s = 0;
		dx = (bi - ai) / (double) n; 
		for (int i = 1; i < n; i++){
			s += f.Func(ai + (i/n) * (bi - ai));
		}
		s += (f.Func(ai) + f.Func(bi))/2;
		s *= dx;
		wynik_t = s;
	}

}
