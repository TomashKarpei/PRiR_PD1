package calki;

import java.util.Scanner;

public class Glowna {
	
	public double Func(double x)
	{
		return (x*x + 5.2)/(Math.sin(0.5+0.1*x*x)); // funkcja
	}

	public static void main(String[] args) {
		
		double a = 0, b = 0, n = 0;
		
		Scanner myObj = new Scanner(System.in); 
		
	    System.out.println("\nPodaj poczatek przedzialu: "); // skanowanie poczatku, konca oraz dok�adno�ci przedzia�u (dla danego przyk�adu by�o wybrano a=1, b=4, n=6);
	    a = myObj.nextDouble();
	    System.out.println("\nPodaj koniec przedzialu: ");
	    b = myObj.nextDouble();
	    System.out.println("Podaj dok�adno�� przedzialu: ");
	    n = myObj.nextDouble(); 
	
		M_prostokatow  mp = new M_prostokatow(a, b, n);
		mp.start(); 
		M_trapezow mt = new M_trapezow(a, b, n); 
		mt.start(); 
		M_Simpsona ms = new M_Simpsona(a, b, n); 
		ms.start(); 
		try { 
		mp.join(); 
		mt.join();
		ms.join();
		System.out.println("Wynik dla metody prostokatow: " + mp.wynik_p + "\n");
		System.out.println("Wynik dla metody trapezow: " + mt.wynik_t + "\n");
		System.out.println("Wynik dla metody Simpsona: " + ms.wynik_S + "\n");
		} 
		catch (Exception e) { 
		e.printStackTrace(); 
		} 
		
	}
}
